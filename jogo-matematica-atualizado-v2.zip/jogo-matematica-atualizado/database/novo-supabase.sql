-- ============================================================
-- JOGO DE MATEMÁTICA - NOVO BANCO SUPABASE
-- ============================================================
-- ANTES DE EXECUTAR:
-- 1) Localize PIN_ADMIN_AQUI neste arquivo.
-- 2) Troque por um PIN numérico de 4 dígitos escolhido por você.
-- 3) Execute o arquivo completo no SQL Editor do Supabase.
--
-- O PIN é armazenado somente como hash. Não coloque a service_role
-- nem qualquer chave secreta no GitHub.
-- ============================================================

create extension if not exists pgcrypto with schema extensions;

create table if not exists public.math_students (
  id text primary key,
  full_name text not null,
  progress jsonb not null default '{"completed":{},"attempts":[],"lastPlayed":null}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint math_students_id_check check (id ~ '^[a-z0-9]+(?:-[a-z0-9]+)*$'),
  constraint math_students_name_check check (char_length(trim(full_name)) between 3 and 120),
  constraint math_students_progress_check check (jsonb_typeof(progress) = 'object')
);

create table if not exists public.math_teachers (
  id text primary key,
  full_name text not null,
  pin_hash text not null,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint math_teachers_id_check check (id ~ '^[a-z0-9]+(?:-[a-z0-9]+)*$'),
  constraint math_teachers_name_check check (char_length(trim(full_name)) between 3 and 120)
);

create table if not exists public.math_app_config (
  key text primary key,
  value_hash text not null,
  updated_at timestamptz not null default now()
);

create table if not exists public.math_staff_sessions (
  token uuid primary key default extensions.gen_random_uuid(),
  role text not null check (role in ('admin', 'teacher')),
  staff_id text not null,
  full_name text not null,
  expires_at timestamptz not null default (now() + interval '8 hours'),
  created_at timestamptz not null default now()
);

create table if not exists public.math_login_attempts (
  user_id text primary key,
  failed_attempts integer not null default 0,
  blocked_until timestamptz,
  updated_at timestamptz not null default now()
);

-- Troque PIN_ADMIN_AQUI antes de executar este arquivo.
insert into public.math_app_config (key, value_hash)
values ('admin_pin', extensions.crypt('PIN_ADMIN_AQUI', extensions.gen_salt('bf')))
on conflict (key) do nothing;

create or replace function public.set_math_updated_at()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists math_students_set_updated_at on public.math_students;
create trigger math_students_set_updated_at
before update on public.math_students
for each row execute function public.set_math_updated_at();

drop trigger if exists math_teachers_set_updated_at on public.math_teachers;
create trigger math_teachers_set_updated_at
before update on public.math_teachers
for each row execute function public.set_math_updated_at();

-- Mescla o progresso recebido com o que já existe no banco.
-- Assim, uma gravação antiga não apaga tentativas mais recentes.
create or replace function public.math_merge_progress(p_old jsonb, p_new jsonb)
returns jsonb
language plpgsql
immutable
set search_path = public
as $$
declare
  old_progress jsonb := coalesce(p_old, '{"completed":{},"attempts":[],"lastPlayed":null}'::jsonb);
  new_progress jsonb := coalesce(p_new, '{"completed":{},"attempts":[],"lastPlayed":null}'::jsonb);
  merged_completed jsonb;
  merged_attempts jsonb;
  merged_last_played jsonb;
begin
  if jsonb_typeof(old_progress) <> 'object' or jsonb_typeof(new_progress) <> 'object' then
    raise exception 'Formato de progresso inválido';
  end if;

  if jsonb_array_length(coalesce(new_progress->'attempts', '[]'::jsonb)) > 1500 then
    raise exception 'Quantidade de tentativas acima do limite';
  end if;

  with level_keys as (
    select jsonb_object_keys(coalesce(old_progress->'completed', '{}'::jsonb)) as level_key
    union
    select jsonb_object_keys(coalesce(new_progress->'completed', '{}'::jsonb)) as level_key
  )
  select coalesce(
    jsonb_object_agg(
      level_key,
      coalesce(old_progress->'completed'->level_key, '{}'::jsonb)
      || coalesce(new_progress->'completed'->level_key, '{}'::jsonb)
      || jsonb_build_object(
        'passed',
          coalesce((old_progress->'completed'->level_key->>'passed')::boolean, false)
          or coalesce((new_progress->'completed'->level_key->>'passed')::boolean, false),
        'stars', greatest(
          coalesce((old_progress->'completed'->level_key->>'stars')::integer, 0),
          coalesce((new_progress->'completed'->level_key->>'stars')::integer, 0)
        ),
        'bestScore', greatest(
          coalesce((old_progress->'completed'->level_key->>'bestScore')::integer, 0),
          coalesce((new_progress->'completed'->level_key->>'bestScore')::integer, 0)
        ),
        'bestCorrect', greatest(
          coalesce((old_progress->'completed'->level_key->>'bestCorrect')::integer, 0),
          coalesce((new_progress->'completed'->level_key->>'bestCorrect')::integer, 0)
        )
      )
    ),
    '{}'::jsonb
  )
  into merged_completed
  from level_keys;

  with all_attempts as (
    select value as attempt,
           coalesce(value->>'id', md5(value::text)) as attempt_key
    from jsonb_array_elements(
      coalesce(old_progress->'attempts', '[]'::jsonb)
      || coalesce(new_progress->'attempts', '[]'::jsonb)
    )
  ),
  unique_attempts as (
    select distinct on (attempt_key) attempt
    from all_attempts
    order by attempt_key, coalesce(attempt->>'date', '') desc
  )
  select coalesce(
    jsonb_agg(attempt order by coalesce(attempt->>'date', '')),
    '[]'::jsonb
  )
  into merged_attempts
  from unique_attempts;

  merged_last_played := case
    when new_progress ? 'lastPlayed' and new_progress->'lastPlayed' <> 'null'::jsonb
      then new_progress->'lastPlayed'
    else old_progress->'lastPlayed'
  end;

  return jsonb_build_object(
    'completed', merged_completed,
    'attempts', merged_attempts,
    'lastPlayed', coalesce(merged_last_played, 'null'::jsonb)
  );
end;
$$;

alter table public.math_students enable row level security;
alter table public.math_teachers enable row level security;
alter table public.math_app_config enable row level security;
alter table public.math_staff_sessions enable row level security;
alter table public.math_login_attempts enable row level security;

-- Nenhuma tabela pode ser lida ou alterada diretamente pela chave pública.
revoke all on table public.math_students from anon, authenticated;
revoke all on table public.math_teachers from anon, authenticated;
revoke all on table public.math_app_config from anon, authenticated;
revoke all on table public.math_staff_sessions from anon, authenticated;
revoke all on table public.math_login_attempts from anon, authenticated;

create or replace function public.math_student_get(p_id text)
returns jsonb
language sql
security definer
set search_path = public
as $$
  select jsonb_build_object(
    'id', s.id,
    'full_name', s.full_name,
    'progress', s.progress,
    'created_at', s.created_at,
    'updated_at', s.updated_at
  )
  from public.math_students s
  where s.id = trim(p_id)
  limit 1;
$$;

create or replace function public.math_student_save(
  p_id text,
  p_full_name text,
  p_progress jsonb
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  existing_progress jsonb;
  merged_progress jsonb;
  saved public.math_students;
begin
  if coalesce(length(trim(p_id)), 0) < 2
     or trim(p_id) !~ '^[a-z0-9]+(?:-[a-z0-9]+)*$'
     or coalesce(length(trim(p_full_name)), 0) not between 3 and 120 then
    raise exception 'Dados do aluno inválidos';
  end if;

  select progress into existing_progress
  from public.math_students
  where id = trim(p_id)
  for update;

  merged_progress := public.math_merge_progress(existing_progress, p_progress);

  insert into public.math_students (id, full_name, progress)
  values (trim(p_id), trim(p_full_name), merged_progress)
  on conflict (id) do update
  set full_name = excluded.full_name,
      progress = public.math_merge_progress(public.math_students.progress, excluded.progress),
      updated_at = now()
  returning * into saved;

  return jsonb_build_object(
    'id', saved.id,
    'full_name', saved.full_name,
    'progress', saved.progress,
    'created_at', saved.created_at,
    'updated_at', saved.updated_at
  );
end;
$$;

create or replace function public.math_staff_login(
  p_user_id text,
  p_pin text
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  teacher_row public.math_teachers;
  stored_hash text;
  session_token uuid;
  login_role text;
  login_id text;
  login_name text;
  attempts_row public.math_login_attempts;
  next_failed integer;
begin
  p_user_id := trim(p_user_id);

  if p_pin !~ '^[0-9]{4}$' then
    return null;
  end if;

  delete from public.math_staff_sessions where expires_at <= now();

  select * into attempts_row
  from public.math_login_attempts
  where user_id = p_user_id;

  if found and attempts_row.blocked_until is not null and attempts_row.blocked_until > now() then
    return null;
  end if;

  if p_user_id = 'eric-ablon-dos-santos-cerqueira' then
    select value_hash into stored_hash
    from public.math_app_config
    where key = 'admin_pin';

    if stored_hash is not null and extensions.crypt(p_pin, stored_hash) = stored_hash then
      login_role := 'admin';
      login_id := 'eric-ablon-dos-santos-cerqueira';
      login_name := 'ERIC ABLON DOS SANTOS CERQUEIRA';
    end if;
  else
    select * into teacher_row
    from public.math_teachers
    where id = p_user_id and active = true;

    if found and extensions.crypt(p_pin, teacher_row.pin_hash) = teacher_row.pin_hash then
      login_role := 'teacher';
      login_id := teacher_row.id;
      login_name := teacher_row.full_name;
    end if;
  end if;

  if login_role is null then
    next_failed := case
      when attempts_row.user_id is null or attempts_row.blocked_until is not null and attempts_row.blocked_until <= now() then 1
      else attempts_row.failed_attempts + 1
    end;

    insert into public.math_login_attempts (user_id, failed_attempts, blocked_until, updated_at)
    values (
      p_user_id,
      next_failed,
      case when next_failed >= 5 then now() + interval '15 minutes' else null end,
      now()
    )
    on conflict (user_id) do update
    set failed_attempts = excluded.failed_attempts,
        blocked_until = excluded.blocked_until,
        updated_at = now();

    return null;
  end if;

  delete from public.math_login_attempts where user_id = p_user_id;
  delete from public.math_staff_sessions where staff_id = login_id and created_at < now() - interval '1 minute';

  insert into public.math_staff_sessions (role, staff_id, full_name)
  values (login_role, login_id, login_name)
  returning token into session_token;

  return jsonb_build_object(
    'token', session_token,
    'role', login_role,
    'id', login_id,
    'full_name', login_name
  );
end;
$$;

create or replace function public.math_staff_dashboard(p_token uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  valid_session boolean;
  result jsonb;
begin
  select exists(
    select 1 from public.math_staff_sessions
    where token = p_token and expires_at > now()
  ) into valid_session;

  if not valid_session then
    raise exception 'Sessão inválida ou expirada' using errcode = '42501';
  end if;

  select coalesce(jsonb_agg(
    jsonb_build_object(
      'id', s.id,
      'full_name', s.full_name,
      'progress', s.progress,
      'created_at', s.created_at,
      'updated_at', s.updated_at
    ) order by s.full_name
  ), '[]'::jsonb)
  into result
  from public.math_students s;

  return result;
end;
$$;

create or replace function public.math_admin_list_teachers(p_token uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  is_admin boolean;
  result jsonb;
begin
  select exists(
    select 1 from public.math_staff_sessions
    where token = p_token and role = 'admin' and expires_at > now()
  ) into is_admin;

  if not is_admin then
    raise exception 'Acesso restrito ao administrador' using errcode = '42501';
  end if;

  select coalesce(jsonb_agg(
    jsonb_build_object(
      'id', t.id,
      'full_name', t.full_name,
      'active', t.active,
      'created_at', t.created_at,
      'updated_at', t.updated_at
    ) order by t.full_name
  ), '[]'::jsonb)
  into result
  from public.math_teachers t;

  return result;
end;
$$;

create or replace function public.math_admin_upsert_teacher(
  p_token uuid,
  p_id text,
  p_full_name text,
  p_pin text
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  is_admin boolean;
  saved public.math_teachers;
begin
  select exists(
    select 1 from public.math_staff_sessions
    where token = p_token and role = 'admin' and expires_at > now()
  ) into is_admin;

  if not is_admin then
    raise exception 'Acesso restrito ao administrador' using errcode = '42501';
  end if;

  if p_pin !~ '^[0-9]{4}$'
     or coalesce(length(trim(p_full_name)), 0) not between 3 and 120
     or trim(p_id) !~ '^[a-z0-9]+(?:-[a-z0-9]+)*$'
     or trim(p_id) = 'eric-ablon-dos-santos-cerqueira' then
    raise exception 'Dados do professor inválidos';
  end if;

  insert into public.math_teachers (id, full_name, pin_hash, active)
  values (trim(p_id), trim(p_full_name), extensions.crypt(p_pin, extensions.gen_salt('bf')), true)
  on conflict (id) do update
  set full_name = excluded.full_name,
      pin_hash = excluded.pin_hash,
      active = true,
      updated_at = now()
  returning * into saved;

  return jsonb_build_object(
    'id', saved.id,
    'full_name', saved.full_name,
    'active', saved.active,
    'created_at', saved.created_at,
    'updated_at', saved.updated_at
  );
end;
$$;

create or replace function public.math_admin_toggle_teacher(
  p_token uuid,
  p_id text
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  is_admin boolean;
  saved public.math_teachers;
begin
  select exists(
    select 1 from public.math_staff_sessions
    where token = p_token and role = 'admin' and expires_at > now()
  ) into is_admin;

  if not is_admin then
    raise exception 'Acesso restrito ao administrador' using errcode = '42501';
  end if;

  update public.math_teachers
  set active = not active,
      updated_at = now()
  where id = trim(p_id)
  returning * into saved;

  if not found then
    raise exception 'Professor não encontrado';
  end if;

  return jsonb_build_object(
    'id', saved.id,
    'full_name', saved.full_name,
    'active', saved.active,
    'created_at', saved.created_at,
    'updated_at', saved.updated_at
  );
end;
$$;

-- Remove a permissão padrão de execução concedida ao papel PUBLIC.
revoke all on function public.set_math_updated_at() from public;
revoke all on function public.math_merge_progress(jsonb, jsonb) from public, anon, authenticated;
revoke all on function public.math_student_get(text) from public;
revoke all on function public.math_student_save(text, text, jsonb) from public;
revoke all on function public.math_staff_login(text, text) from public;
revoke all on function public.math_staff_dashboard(uuid) from public;
revoke all on function public.math_admin_list_teachers(uuid) from public;
revoke all on function public.math_admin_upsert_teacher(uuid, text, text, text) from public;
revoke all on function public.math_admin_toggle_teacher(uuid, text) from public;

grant execute on function public.math_student_get(text) to anon, authenticated;
grant execute on function public.math_student_save(text, text, jsonb) to anon, authenticated;
grant execute on function public.math_staff_login(text, text) to anon, authenticated;
grant execute on function public.math_staff_dashboard(uuid) to anon, authenticated;
grant execute on function public.math_admin_list_teachers(uuid) to anon, authenticated;
grant execute on function public.math_admin_upsert_teacher(uuid, text, text, text) to anon, authenticated;
grant execute on function public.math_admin_toggle_teacher(uuid, text) to anon, authenticated;

create index if not exists math_students_updated_at_idx on public.math_students (updated_at desc);
create index if not exists math_teachers_active_idx on public.math_teachers (active);
create index if not exists math_staff_sessions_expiry_idx on public.math_staff_sessions (expires_at);
create index if not exists math_staff_sessions_staff_idx on public.math_staff_sessions (staff_id, created_at desc);
create index if not exists math_login_attempts_block_idx on public.math_login_attempts (blocked_until);

-- Para trocar o PIN do administrador futuramente, execute no SQL Editor:
-- update public.math_app_config
-- set value_hash = extensions.crypt('NOVO_PIN_DE_4_DIGITOS', extensions.gen_salt('bf')),
--     updated_at = now()
-- where key = 'admin_pin';
